import { NavigationContainer } from '@react-navigation/native';
import React from 'react';
import Home from './src';

function App() {

  return (

    <Home />
   
  );
}

export default App;