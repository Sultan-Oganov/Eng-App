import React from "react";
import PropTypes from 'prop-types';
import WorkScenes from "./workscenes";
import AuthScenes from "./authscenes";

const Home = ({ isAuth }) => {

  return (
    isAuth
      ? <WorkScenes />
      : <AuthScenes />
  );
}

Home.propTypes = {
  isAuth: PropTypes.bool
};

Home.defaultProps = {
  isAuth: false
};

export default Home;