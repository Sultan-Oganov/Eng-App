import React from 'react'
import { StyleSheet } from 'react-native';
import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";
import Tabs from '../authscenes/Tabs'
import MainPage from '../authscenes/Tabs/MainPage';
import Forum from '../authscenes/Tabs/Forum';
import Profile from '../authscenes/Tabs/Profile';

const WorkScenes = () => {

    const Stack = createStackNavigator()
    return (
     <NavigationContainer>
                <Stack.Navigator screenOptions={{ headerStyle: { backgroundColor: 'red' } }}>
                    {/* <Stack.Screen name='Tabs' options={{ headerShown: false }} component={Tabs} />
                    <Stack.Screen name='MainPage' options={{ headerShown: false }} component={MainPage} />
                    <Stack.Screen name='Forum' options={{ headerShown: false }} component={Forum} />
                    <Stack.Screen name='Profile' options={{ headerShown: false }} component={Profile} /> */}
                </Stack.Navigator>
     </NavigationContainer>

    )
}

const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: "white",
      alignItems: "center",
      justifyContent: "center",
    },
  });
  
export default WorkScenes;