import React from "react";
import { StyleSheet } from "react-native";
import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";
import Login from "./Login";
import LoginEmail from "./LoginEmail";
import Registration from "./Registration";
import Tabs from "./Tabs";
import MainPage from "./Tabs/MainPage";
import Profile from "./Tabs/Profile";
import Info from "./Tabs/MainPage/Info";
import InfoTerm from "./Tabs/MainPage/Info/InfoTerm";
import InfoTermDescription from "./Tabs/MainPage/Info/InfoTermDescription";
import Media from "./Tabs/MainPage/Media";
import MediaVideo from "./Tabs/MainPage/Media/MediaVideo";
import Contacts from "./Tabs/MainPage/Contacts";
import ProfileEditPass from "./Tabs/Profile/ProfileEditPass";
import ContactsMap from "./Tabs/MainPage/Contacts/ContactsMap";
import TestMain from "./Tabs/MainPage/TestMain";
import Test from "./Tabs/MainPage/TestMain/Test";
import Forum from "./Tabs/Forum";
import Forum1 from "./Tabs/Forum/Forum1";
import Forum2 from "./Tabs/Forum/Forum2";
import ForumCreate from "./Tabs/Forum/ForumCreate";
import Share from "./Tabs/Forum/Share";
import TestResult from "./Tabs/MainPage/TestMain/TestResult";
import ContactsReview from "./Tabs/MainPage/Contacts/ContactsReview";
import ContactsLegal from "./Tabs/MainPage/Contacts/ContactsLegal";
import Article from "./Tabs/MainPage/Info/Article";
import Pills from "./Tabs/MainPage/Pills";
import PillsAdd from "./Tabs/MainPage/PillsAdd";
const AuthScenes = () => {
  const Stack = createStackNavigator();
  return (
    <NavigationContainer>
      <Stack.Navigator
        screenOptions={{ headerStyle: { backgroundColor: "red" } }}
      >
          <Stack.Screen
          name="Login"
          options={{ headerShown: false }}
          component={Login}
        />
        <Stack.Screen
          name="ContactsReview"
          options={{ headerShown: false }}
          component={ContactsReview}
        />
        <Stack.Screen
          name="ContactsMap"
          options={{ headerShown: false }}
          component={ContactsMap}
        />
        <Stack.Screen
          name="TestMain"
          options={{ headerShown: false }}
          component={TestMain}
        />

        <Stack.Screen
          name="Registration"
          options={{ headerShown: false }}
          component={Registration}
        />
            <Stack.Screen
          name="Article"
          options={{ headerShown: false }}
          component={Article}
        />

            <Stack.Screen
          name="Pills"
          options={{ headerShown: false }}
          component={Pills}
        />
                    <Stack.Screen
          name="PillsAdd"
          options={{ headerShown: false }}
          component={PillsAdd}
        />
        <Stack.Screen
          name="LoginEmail"
          options={{ headerShown: false }}
          component={LoginEmail}
        />
        <Stack.Screen
          name="MainPage"
          options={{ headerShown: false }}
          component={MainPage}
        />

        <Stack.Screen
          name="Test"
          options={{ headerShown: false }}
          component={Test}
        />
        <Stack.Screen
          name="TestResult"
          options={{ headerShown: false }}
          component={TestResult}
        />
        <Stack.Screen
          name="Forum"
          options={{ headerShown: false }}
          component={Forum}
        />
        <Stack.Screen
          name="Forum1"
          options={{ headerShown: false }}
          component={Forum1}
        />
        <Stack.Screen
          name="Forum2"
          options={{ headerShown: false }}
          component={Forum2}
        />
        <Stack.Screen
          name="ForumCreate"
          options={{ headerShown: false }}
          component={ForumCreate}
        />

        <Stack.Screen
          name="Share"
          options={{ headerShown: false }}
          component={Share}
        />
        <Stack.Screen
          name="Profile"
          options={{ headerShown: false }}
          component={Profile}
        />
        <Stack.Screen
          name="ProfileEditPass"
          options={{ headerShown: false }}
          component={ProfileEditPass}
        />
        <Stack.Screen
          name="Tabs"
          options={{ headerShown: false }}
          component={Tabs}
        />
        <Stack.Screen
          name="Info"
          options={{ headerShown: false }}
          component={Info}
        />
        <Stack.Screen
          name="InfoTerm"
          options={{ headerShown: false }}
          component={InfoTerm}
        />
        <Stack.Screen
          name="InfoTermDescription"
          options={{ headerShown: false }}
          component={InfoTermDescription}
        />
        <Stack.Screen
          name="Media"
          options={{ headerShown: false }}
          component={Media}
        />
        <Stack.Screen
          name="MediaVideo"
          options={{ headerShown: false }}
          component={MediaVideo}
        />
        <Stack.Screen
          name="Contacts"
          options={{ headerShown: false }}
          component={Contacts}
        />
        <Stack.Screen
          name="ContactsLegal"
          options={{ headerShown: false }}
          component={ContactsLegal}
        />

       
      </Stack.Navigator>
      <Tabs/>
    </NavigationContainer>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "white",
    alignItems: "center",
    justifyContent: "center",
  },
});

export default AuthScenes;
