import { useNavigation } from '@react-navigation/core';
import React, { useState, useEffect } from 'react'
import { View, Text, StyleSheet, TouchableOpacity, Dimensions, TouchableHighlight, Image, ScrollView, Platform } from 'react-native'
import { LinearGradient } from 'expo-linear-gradient'
import Backicon from '../../../../../../assets/images/backicon.svg'
import Line from '../../../../../../assets/images/line.svg'
import Next from '../../../../../../assets/images/next.svg'
import Divider from '../../../../../../assets/images/divider.svg'
import BackWhite from '../../../../../../assets/images/testBackWhite.png'
import BackBlue from '../../../../../../assets/images/testBackBlue.png'
import NextBlue from '../../../../../../assets/images/testNextBlue.png'
import NextWhite from '../../../../../../assets/images/testNextWhite.png'




export default function Test() {

  const [progressMaxNum, setProgressMaxNum] = useState(13)
  const [progressNum, setProgressNum] = useState(1)
  const [allProgress, setAllProgress] = useState(7.6923076923076925)
  const [trueWords, setTrueWords] = useState(false)
  const [falseWords, setFalseWords] = useState(true)
  const [falseWords2, setFalseWords2] = useState(true)

  const [trueText, setTrueText] = useState(false)
  const [falseText2, setFalseText2] = useState(true)
  const [falseText3, setFalseText3] = useState(true)

  const [complate, setComplate] = useState(0)
  const [compBool, setCompBool] = useState(0)


  const [state1, setState1] = useState(false)
  const [state2, setState2] = useState(true)
  const [state3, setState3] = useState(true)

  const [modal, setModal] = useState(false)
  const [statusModal, setStatusModal] = useState()

  const [btn, setBtn] = useState(false)
  const [btn2, setBtn2] = useState(false)





  const navigation = useNavigation();
  const num = 7.6923076923076925

  const changeBackProgress = () => {
    progressNum == 1 ? null : setProgressNum(progressNum - 1)
    setAllProgress(allProgress - num)
    setModal(false)
    setModal(false)
    next()
  }
  const changeNextProgress = () => {
    progressNum !== progressMaxNum ?
      setProgressNum(progressNum + 1) : null
    setAllProgress(num + allProgress)
    setModal(false)
    next()

  }

  const wordsCheck = (setState, state) => {
    setState(state ? false : true)
    setTrueWords(true)
    modalStatus(setState, state)
    setModal(true)
    setTimeout(() => {
      changeNextProgress()
    }, 1000);
  }



  const modalStatus = (setState, state) => {
    state == true ? setStatusModal(false) : setStatusModal(true)
    state == true ? setComplate(1) : setComplate(0)
    state == true ? setCompBool(1) : setCompBool(2)

  }

  const next = () => {
    setComplate(0)
    setCompBool(0)
    setTrueWords(false)
    setTrueText(false)
    setFalseWords(true)
    setFalseWords2(true)
    setFalseText2(true)
    setFalseText3(true)
    setState1(false)
    setState2(true)
    setState3(true)



  }





  return (
    <View
      style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity
          onPress={() => navigation.navigate("MainPage")}
          style={styles.backView}
        >
          <Backicon width={20} />
        </TouchableOpacity>
        <View style={styles.textView}>
          <Text style={styles.headerText}>Teст{" " + progressNum}</Text>
          <Line width={25} marginLeft={25} />
        </View>

      </View>
      <View style={{ width: '92%', backgroundColor: 'silver', height: 1,marginTop:'7%', alignSelf:'center',}}></View>

      <ScrollView>
      <View style={styles.content}>

        <View style={styles.contentQuest}>
          <TouchableHighlight
            style={
              compBool == 0 ? styles.curcleBtn : compBool == 1 ? styles.curcleBtnFalse : compBool == 2 ? styles.curcleBtnTrue : null
            }
            underlayColor='#ccc'
          >
            <Text style={complate == 0 ? styles.contentNumber : complate == 1 ? styles.contentNumberFalse : null}> 1 </Text>
          </TouchableHighlight>

          <Text style={styles.contentText}>
            Какая болезнь вызывается бледной спирохетой:
          </Text>
        </View>

        <View style={styles.testVariants}>

          <TouchableOpacity backgroundColor={'white'} style={state1 == true ? styles.trueVariants : styles.variants}
            onPress={() => { wordsCheck(setState1, state1), setTrueText(true) }}
          >
            <View style={trueWords ? styles.trueVariantsCheck : styles.variantsCheck}></View>
            <Text style={trueText ? styles.trueVariantsText : styles.variantsText}>Сифилис</Text>
          </TouchableOpacity>

          <TouchableOpacity style={state2 == false ? styles.trueVariants : styles.variants}
            onPress={() => { wordsCheck(setState2, state2), setFalseWords(false), setFalseText2(false) }}
          >
            <View style={falseWords == false ? styles.falseVariantsCheck : styles.variantsCheck}></View>
            <Text style={falseText2 == false ? styles.falseVariantsText : styles.variantsText}>Генительный герпес</Text>
          </TouchableOpacity>

          <TouchableOpacity style={state3 == false ? styles.trueVariants : styles.variants}
            onPress={() => { wordsCheck(setState3, state3), setFalseWords2(false), setFalseText3(false) }}
          >
            <View style={falseWords2 == false ? styles.falseVariantsCheck : styles.variantsCheck}></View>
            <Text style={falseText3 == false ? styles.falseVariantsText : styles.variantsText}>Трихомоноз</Text>
          </TouchableOpacity>

        </View>

        {modal ?

          <View style={styles.question}>
            <TouchableHighlight
              style={
                {
                  borderRadius: Math.round(Dimensions.get('window').width + Dimensions.get('window').height) / 2,
                  width: Dimensions.get('window').width * 0.16,
                  height: Dimensions.get('window').width * 0.16,
                  backgroundColor: 'white',
                  justifyContent: 'center',
                  alignItems: 'center',
                  borderWidth: 2,
                  borderStyle: 'solid',
                  borderColor: statusModal ? '#26E415' : '#B4D1D7',
                  margin: 10,
                  alignSelf: 'center',
                }
              }
              underlayColor='#ccc'
            >
              <Text style={statusModal ? styles.trueQuest : styles.falseQuest}> ! </Text>
            </TouchableHighlight>
            <View style={styles.questText}>
              <Text style={styles.contentTextUp}>
                {statusModal ? 'Правильно!' : 'Правильный ответ:'}
              </Text>
              <Text style={styles.contentTextBot}>
                Сифилис
              </Text>
            </View>


            <TouchableOpacity
              style={styles.btnQuest}
            >
              <Text style={{  color: 'white', fontWeight: '400', }}>
                {statusModal ? 'ПОДРОБНЕЕ' : 'ПОЧЕМУ?'}
              </Text>
            </TouchableOpacity>



          </View>
          : null
        }


        <View
          style={Platform.OS == 'ios' ? {
            width: '100%',
            alignItems: 'center',
            marginTop: modal ? deviceHeight * 0.019 : deviceHeight * 0.2,
          } : {
            width: '100%',
            alignItems: 'center',
            marginTop: modal ? deviceHeight * 0.01 : deviceHeight * 0.17,
          }
          } >

          <View style={styles.progressTop}>
            <TouchableHighlight style={styles.progressBack}
              onPress={
                () => { progressNum == 1 ? null : changeBackProgress() }}
              underlayColor='transparent'
            >
              <Image source={progressNum == 1 ? BackWhite : BackBlue}
              />
            </TouchableHighlight>

            <Text style={{ fontSize: 20, alignSelf: 'center', }}>
              {progressNum} <Text style={{ fontSize: 13 }}>/{progressMaxNum}</Text></Text>


            <TouchableHighlight style={styles.progressBack}
              onPress={
                () => { progressNum < 13 ? changeNextProgress() : null }}
              underlayColor='transparent'
            >
              <Image source={progressNum < 13 ? NextBlue : NextWhite} />
            </TouchableHighlight>
          </View>


          <View style={styles.progressBottom}>
            {Platform.OS == 'android' ?
              <LinearGradient
                width={allProgress + '%'}
                style={{ height: 4, borderRadius: 10, }}
                colors={['#159CE4', '#4AD0EE']}
              ></LinearGradient>
              :
              <LinearGradient
                style={{ height: 4, width: allProgress + '%', borderRadius: 2, }}
                colors={['#159CE4', '#4AD0EE']}
              ></LinearGradient>
            }


          </View>




          <View style={styles.btnMain}>
            <TouchableOpacity
              onPress={
                () => { setBtn(!btn); navigation.navigate('TestResult') }}
              style={btn ? styles.buttonstyle2 : styles.buttonstyle1
              }>

              <Text style={btn ? styles.textbutton2 : styles.textbutton1}>Завершить тест</Text>

            </TouchableOpacity>


            <TouchableOpacity
              onPress={() => {
                setBtn2(!btn2),
                progressNum < 13 ? changeNextProgress() : null
              }
              }
              style={btn2 ? styles.buttonstyle2 : styles.buttonstyle1}
            >
              <Text style={btn2 ? styles.textbutton2 : styles.textbutton1}>Следующий вопрос</Text>
            </TouchableOpacity>

          </View>
        </View>
      </View>
      </ScrollView>
    </View>
  );
}

const deviceHeight = Dimensions.get('window').height;
const deviceWidth = Dimensions.get('window').width;

const styles = StyleSheet.create({
  curcleBtn: {
    borderRadius: Math.round(Dimensions.get('window').width + Dimensions.get('window').height) / 2,
    width: Dimensions.get('window').width * 0.16,
    height: Dimensions.get('window').width * 0.16,
    backgroundColor: 'white',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderStyle: 'solid',
    borderColor: '#F2F3F4',
    margin: 10,
    alignSelf: 'center',
  },
  curcleBtnTrue: {
    borderRadius: Math.round(Dimensions.get('window').width + Dimensions.get('window').height) / 2,
    width: Dimensions.get('window').width * 0.16,
    height: Dimensions.get('window').width * 0.16,
    backgroundColor: 'white',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderStyle: 'solid',
    borderColor: '#26E415',
    margin: 10,
    alignSelf: 'center',
  },
  curcleBtnFalse: {
    borderRadius: Math.round(Dimensions.get('window').width + Dimensions.get('window').height) / 2,
    width: Dimensions.get('window').width * 0.16,
    height: Dimensions.get('window').width * 0.16,
    backgroundColor: 'white',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderStyle: 'solid',
    borderColor: '#F03800',
    margin: 10,
    alignSelf: 'center',
  },

  questText: {
    width: '40%',
    alignSelf: 'center',
  },
  contentTextBot: {
    fontWeight: '700',
    fontSize: 17,

  },
  contentTextUp: {
    fontWeight: '500',
    fontSize: 15,

  },
  trueQuest: {
    fontSize: 25,
    color: '#26E415',
    fontWeight: '700',
  },
  falseQuest: {
    fontSize: 25,
    color: '#B4D1D7',
    fontWeight: '700',
  },
  question: {
    width: '90%',
    backgroundColor: 'white',
    marginTop: '6%',
    marginBottom: '5%',

    flexDirection: 'row',
    borderRadius: 20,

    shadowOffset: {
      width: 1,
      height: 2,
    },
    shadowOpacity: 0.35,
    shadowRadius: 5,
    shadowColor:'#159CE4',
    elevation: 5,
  },
  trueVariants: {
    width: '100%',
    flexDirection: 'row',
    padding: 10,
    backgroundColor: 'white',
    marginTop: 10,
  },

  btnMain: {
    width: '94%',
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: '5%',


  },
  btnComplate: {
    width: '48%',
    height: 55,
    borderWidth: 3,
    borderStyle: 'solid',
    borderColor: '#159CE4',
    borderRadius: 25,
  },
  btnQuest: {
    width: '28%',
    alignItems: 'center',
    alignSelf: 'center',
    justifyContent:'center',
    height: 50,
    borderRadius: 20,
    backgroundColor: '#159CE4',
    marginLeft: 5,
    
  },
  btnNext: {
    width: '48%',
    textAlign: 'center',
    height: 55,
    borderRadius: 25,
    backgroundColor: '#159CE4',
  },
  container: {
    backgroundColor: "#E5E5E5",
    flex: 1,
  },
  header: {
    flexDirection: "row",
    width: 230,
    paddingTop: 50,
    justifyContent: "center",
  },
  backView: {
    width: 40,
    height: 40,
    backgroundColor: "#fff",
    alignItems: "center",
    borderRadius: 20,
    justifyContent: "center",
    marginRight: 90,
  },
  backIcon: {
    width: 10,
    height: 10,
  },
  headerText: {
    fontSize: 20,
    fontWeight: "700",
    marginTop: 6,
    letterSpacing: 0.4,
    alignSelf: 'center',
  },
  hederLine: {
    alignSelf: "center",
    marginTop: 4,
  },
  content: {
    width: '100%',
    marginTop: 30,
    alignItems: 'center',
    position: 'relative',
  },
  contentNumberFalse: {
    fontSize: 25,
    color: '#F03800',
    fontWeight: '700',
  },
  contentNumber: {
    fontSize: 25,
    color: '#26E415',
    fontWeight: '700',

  },
  contentQuest: {
    width: '90%',
    backgroundColor: 'white',
    marginBottom: '2%',

    flexDirection: 'row',
    borderRadius: 20,

    shadowOffset: {
      width: 1,
      height: 2,
    },
    shadowOpacity: 0.35,
    shadowRadius: 5,
    shadowColor:'#159CE4',
    elevation: 5,

  },
  contentText: {
    width: '75%',
    fontWeight: '500',
    fontSize: 15,
    alignSelf: 'center',

  },
  testVariants: {
    width: '100%',
  },
  variants: {
    width: '100%',
    padding: 10,
    flexDirection: 'row',
    marginTop: 10,

  },
  trueVariantsCheck: {
    borderRadius: Math.round(Dimensions.get('window').width + Dimensions.get('window').height) / 2,
    width: Dimensions.get('window').width * 0.06,
    height: Dimensions.get('window').width * 0.06,
    backgroundColor: 'white',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 5,
    borderStyle: 'solid',
    borderColor: 'green',
    marginLeft: 15,
    marginRight: 15,
  },
  falseVariantsCheck: {
    borderRadius: Math.round(Dimensions.get('window').width + Dimensions.get('window').height) / 2,
    width: Dimensions.get('window').width * 0.06,
    height: Dimensions.get('window').width * 0.06,
    backgroundColor: 'red',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 5,
    borderStyle: 'solid',
    borderColor: 'red',
    marginLeft: 15,
    marginRight: 15,
  },

  variantsCheck: {
    borderRadius: Math.round(Dimensions.get('window').width + Dimensions.get('window').height) / 2,
    width: Dimensions.get('window').width * 0.06,
    height: Dimensions.get('window').width * 0.06,
    backgroundColor: 'white',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 5,
    borderStyle: 'solid',
    borderColor: '#B4D1D7',
    marginLeft: 15,
    marginRight: 15,

  },
  trueVariantsText: {
    color: 'green',
    fontSize: 18,
  },
  falseVariantsText: {
    color: 'red',
    fontSize: 18,
  },
  variantsText: {
    color: '#374957',
    fontSize: 18,
  },

  progressBack: {
    borderRadius: Math.round(Dimensions.get('window').width + Dimensions.get('window').height) / 2,
    width: Dimensions.get('window').width * 0.16,
    height: Dimensions.get('window').width * 0.16,
    backgroundColor: 'transparent',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderStyle: 'solid',
    borderColor: 'white',

  },
  progressNext: {
    borderRadius: Math.round(Dimensions.get('window').width + Dimensions.get('window').height) / 2,
    width: Dimensions.get('window').width * 0.16,
    height: Dimensions.get('window').width * 0.16,
    backgroundColor: 'transparent',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderStyle: 'solid',
    borderColor: 'white',

  },

  progress: {
    width: '100%',
    alignItems: 'center',
    // position: 'absolute',
    marginTop: deviceHeight * 0.07,

  }, progress2: {
    width: '100%',
    alignItems: 'center',
    // position: 'absolute',
    marginTop: deviceHeight * 0.23,

  },

  progressTop: {
    width: '94%',
    flexDirection: 'row',
    justifyContent: 'space-between',


  },
  progressBottom: {
    marginTop: '2%',
    width: '94%',
    height: 4,
    backgroundColor: 'white',
    borderRadius: 10,

  },

  buttonstyle1: {
    borderColor: "#159CE4",
    borderWidth: 2,
    width: '49%',
    height: 45,
    borderRadius: 20,
    alignContent: "center",
    justifyContent: "center",
  },
  textbutton1: {
    color: "black",
    fontSize: 15,
    textAlign: "center",
  },
  buttonstyle2: {
    backgroundColor: "#159CE4",
    borderColor: "#159CE4",
    borderWidth: 2,
    width: '49%',
    height: 45,
    borderRadius: 20,
    alignContent: "center",
    justifyContent: "center",
  },
  textbutton2: {
    color: "white",
    fontSize: 15,
    textAlign: "center",
  },

})