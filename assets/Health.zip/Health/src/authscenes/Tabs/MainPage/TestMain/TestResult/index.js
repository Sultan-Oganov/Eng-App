import { useNavigation } from '@react-navigation/core';
import React, { useState, useEffect } from 'react'
import { View, Text, StyleSheet, TouchableOpacity, Dimensions, TouchableHighlight, Image, Platform, ScrollView, } from 'react-native'
import { LinearGradient } from 'expo-linear-gradient'
import Backicon from '../../../../../../assets/images/backicon.svg'
import Line from '../../../../../../assets/images/line.svg'
import BackBlue from '../../../../../../assets/images/testBackBlue.png'
import NextWhite from '../../../../../../assets/images/testNextWhite.png'
import NextBlue from '../../../../../../assets/images/testNextBlue.png'

import BackWhite from '../../../../../../assets/images/testBackWhite.png'

import Fire from '../../../../../../assets/images/testResFire.png'




export default function TestResult() {
  const navigation = useNavigation();
  const [progressMaxNum, setProgressMaxNum] = useState(13)
  const [progressNum, setProgressNum] = useState(13)
  const [allProgress, setAllProgress] = useState(7.6923076923076925)
  const [btn, setBtn] = useState(false)
  const [btn2, setBtn2] = useState(false)
  const [btn3, setBtn3] = useState(false)

  return (
    <View
      style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity
          onPress={() => navigation.navigate("MainPage")}
          style={styles.backView}
        >
          <Backicon width={20} />
        </TouchableOpacity>
        <View style={styles.textView}>
          <Text style={styles.headerText}>Teст{" " + progressNum}</Text>
          <Line width={25} marginLeft={25} />
        </View>
      </View>
      <View style={{ width: '92%', backgroundColor: 'silver', height: 1,marginTop:'7%', alignSelf:'center', }}></View>

    <ScrollView>
      <View style={styles.content}>
        <View style={styles.contentQuest}>

          <Image source={Fire} style={{ width: 24, marginLeft: '29%', marginRight: '5%', }} />
          <Text style={styles.contentText}>
            Вы прошли тест!
          </Text>

        </View>

        <View style={styles.contentQuest2}>
          <Text style={{ fontSize: 35, alignSelf: 'center', fontWeight: '700', marginTop: '3%', }}>
            10 <Text style={{ fontSize: 13, color: 'silver', }}>/{progressMaxNum}</Text>
          </Text>

          <Text style={styles.contentText2}>
            правильных ответов
          </Text>
        </View>
        <TouchableOpacity
          onPress={
            () => { setBtn3(!btn3); }}
          style={btn3 ? styles.buttonstyle2 : styles.buttonstyle1
          }>

          <Text style={btn3 ? styles.textbutton2 : styles.textbutton1}>Посмотреть результаты</Text>

        </TouchableOpacity>


        <View style={Platform.OS == 'ios' ? styles.progress : styles.progressA}>

          <View style={styles.progressTop}>
            <TouchableHighlight style={styles.progressBack}
              underlayColor='transparent'
            >
              <Image source={progressNum == 1 ? BackWhite : BackBlue}
              />
            </TouchableHighlight>

            <Text style={{ fontSize: 20, alignSelf: 'center', }}>
              {progressNum} <Text style={{ fontSize: 13 }}>/{progressMaxNum}</Text></Text>


            <TouchableHighlight style={styles.progressBack}
              underlayColor='transparent'
            >
              <Image source={progressNum < 13 ? NextBlue : NextWhite} />
            </TouchableHighlight>
          </View>


          <View style={styles.progressBottom}>
            <LinearGradient
              style={{ height: 4, width: '100%', borderRadius: 2, }}
              colors={['#159CE4', '#4AD0EE']}
            ></LinearGradient>
          </View>




          <View style={styles.btnMain}>
            <TouchableOpacity
              onPress={
                () => { setBtn(!btn); navigation.navigate('TestResult') }}
              style={btn ? styles.buttonstyle2 : styles.buttonstyle1
              }>

              <Text style={btn ? styles.textbutton2 : styles.textbutton1}>Завершить тест</Text>

            </TouchableOpacity>


            <TouchableOpacity
              onPress={() => {
                setBtn2(!btn2),
                progressNum < 13 ? changeNextProgress() : null
              }
              }
              style={btn2 ? styles.buttonstyle2 : styles.buttonstyle1}
            >
              <Text style={btn2 ? styles.textbutton2 : styles.textbutton1}>Следующий вопрос</Text>
            </TouchableOpacity>

          </View>
        </View>

      </View>
      </ScrollView>
    </View>
  );
}
const deviceHeight = Dimensions.get('window').height;
const deviceWidth = Dimensions.get('window').width;

const styles = StyleSheet.create({
  btnMain: {
    width: '94%',
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: '5%',
  },
  btnComplate: {
    width: '48%',
    height: 55,
    borderWidth: 3,
    borderStyle: 'solid',
    borderColor: '#159CE4',
    borderRadius: 25,
  },
  container: {
    backgroundColor: "#E5E5E5",
    flex: 1,
  },
  header: {
    flexDirection: "row",
    width: 230,
    paddingTop: 50,
    justifyContent: "center",
  },

  backView: {
    width: 40,
    height: 40,
    backgroundColor: "#fff",
    alignItems: "center",
    borderRadius: 20,
    justifyContent: "center",
    marginRight: 90,
  },
  backIcon: {
    width: 10,
    height: 10,
  },

  headerText: {
    fontSize: 20,
    fontWeight: "700",
    marginTop: 6,
    letterSpacing: 0.4,
    alignSelf: 'center',
  },
  hederLine: {
    alignSelf: "center",
    marginTop: 4,
  },
  content: {
    width: '100%',
    marginTop: 30,
    alignItems: 'center',
    position: 'relative',
  },


  contentQuest: {
    width: '90%',
    backgroundColor: 'white',
    marginBottom: '5%',
    height: 60,
    flexDirection: 'row',
    borderRadius: 20,
    shadowOffset: {
      width: 1,
      height: 2,
    },
    shadowOpacity: 0.35,
    shadowRadius: 5,
    shadowColor:'#159CE4',
    elevation: 5,
    alignSelf: 'center',
    alignItems: 'center',
    flexDirection: 'row',


  },
  contentQuest2: {
    width: '90%',
    backgroundColor: 'white',
    marginTop: '5%',
    marginBottom: '5%',
    flexDirection: 'row',
    borderRadius: 20,
    height: 100,
    shadowOffset: {
      width: 1,
      height: 2,
    },
    shadowOpacity: 0.35,
    shadowRadius: 5,
    shadowColor:'#159CE4',
    elevation: 5,
    alignItems: 'center',
    flexDirection: 'column',
  },
  contentText2: {
    fontWeight: '700',
    fontSize: 17,
  },


  contentText: {
    width: '75%',
    fontWeight: '500',
    fontSize: 15,
    alignSelf: 'center',
  },
  progressBack: {
    borderRadius: Math.round(Dimensions.get('window').width + Dimensions.get('window').height) / 2,
    width: Dimensions.get('window').width * 0.16,
    height: Dimensions.get('window').width * 0.16,
    backgroundColor: 'transparent',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderStyle: 'solid',
    borderColor: 'white',

  },
  progressNext: {
    borderRadius: Math.round(Dimensions.get('window').width + Dimensions.get('window').height) / 2,
    width: Dimensions.get('window').width * 0.16,
    height: Dimensions.get('window').width * 0.16,
    backgroundColor: 'transparent',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderStyle: 'solid',
    borderColor: 'white',

  },

  progress: {
    width: '100%',
    alignItems: 'center',
    // position: 'absolute',
    marginTop: deviceHeight * 0.17,

  },
  progressA: {
    width: '100%',
    alignItems: 'center',
    // position: 'absolute',
    marginTop: deviceHeight * 0.15,

  },
  progressTop: {
    width: '94%',
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  progressBottom: {
    marginTop: '2%',
    width: '94%',
    height: 4,
    backgroundColor: 'white',
    borderRadius: 10,
  },
  buttonstyle1: {
    borderColor: "#159CE4",
    borderWidth: 2,
    width: '49%',
    height: 45,
    borderRadius: 20,
    alignContent: "center",
    justifyContent: "center",
  },
  textbutton1: {
    color: "black",
    fontSize: 15,
    textAlign: "center",
  },
  buttonstyle2: {
    backgroundColor: "#159CE4",
    borderColor: "#159CE4",
    borderWidth: 2,
    width: '49%',
    height: 45,
    borderRadius: 20,
    alignContent: "center",
    justifyContent: "center",
  },
  textbutton2: {
    color: "white",
    fontSize: 15,
    textAlign: "center",
  },

})