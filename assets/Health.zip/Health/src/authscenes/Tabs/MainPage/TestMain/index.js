import { useNavigation } from '@react-navigation/core';
import React from 'react'
import { View, Text, StyleSheet, TouchableOpacity, Image } from 'react-native'
import Backicon from '../../../../../assets/images/backicon.svg'
import Line from '../../../../../assets/images/line.svg'
import Next from '../../../../../assets/images/next.svg'
import Divider from '../../../../../assets/images/divider.svg'
import Check from '../../../../../assets/images/testMainCheck.png'

export default function TestMain() {
  const navigation = useNavigation();
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity
          onPress={() => navigation.navigate("MainPage")}
          style={styles.backView}
        >
          <Backicon width={20} />
        </TouchableOpacity>
        <View style={styles.textView}>
          <Text style={styles.headerText}>Teсты</Text>
          <Line width={25} marginLeft={25} />
        </View>
      </View>


      <View style={styles.content}>
        <View style={styles.route}>
          <TouchableOpacity style={styles.routes}
            onPress={() =>
              navigation.navigate('Test')}>

            <Text style={styles.routesText}>
              ТECT 1
            </Text>
            <Next />
          </TouchableOpacity>
          <View style={{ width: '94%', backgroundColor: 'silver', height: 1, }}></View>
        </View>

        <View style={styles.route}>
          <TouchableOpacity style={styles.routes}
            onPress={() =>
              navigation.navigate('Test')}>
            <View style={{flexDirection:'row',alignItems:'center',}}>
              <Image source={Check} style={{marginRight:'2%',}} />

              <View style={{marginLeft:'2%',}}>
                <Text style={{color: '#159CE4',fontSize:16,fontWeight:'700',width:100,}}>
                ТECT 2
                </Text>
                <Text>
                  Правильных ответов: 9/13
                </Text>
              </View>
              
            </View>
            
            <Next />
          </TouchableOpacity>
          <View style={{ width: '94%', backgroundColor: 'silver', height: 1, }}></View>
        </View>

        <View style={styles.route}>
          <TouchableOpacity style={styles.routes}
            onPress={() =>
              navigation.navigate('Test')}>

            <Text style={styles.routesText}>
            ТECT 3
            </Text>
            <Next />
          </TouchableOpacity>
          <View style={{ width: '94%', backgroundColor: 'silver', height: 1, }}></View>
        </View>

        <View style={styles.route}>
          <TouchableOpacity style={styles.routes}
            onPress={() =>
              navigation.navigate('Test')}>

            <Text style={styles.routesText}>
            ТECT 4
            </Text>
            <Next />
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: "#E5E5E5",
    flex: 1,
  },
  header: {
    flexDirection: "row",
    width: 230,
    paddingTop: 50,

    justifyContent: "center",
  },
  backView: {
    width: 40,
    height: 40,
    backgroundColor: "#fff",
    alignItems: "center",
    borderRadius: 20,
    justifyContent: "center",
    marginRight: 90,
  },
  backIcon: {
    width: 10,
    height: 10,
  },
  headerText: {
    fontSize: 20,
    fontWeight: "700",
    marginTop: 6,
    letterSpacing: 0.4,
  },
  hederLine: {
    alignSelf: "center",
    marginTop: 4,
  },
  content: {
    marginTop: 30,
  },
  route:{
    alignItems:'center',
  },


  routes: {
    flexDirection: 'row',
    justifyContent:'space-between',
    width: '94%',
    height: 100,
    alignItems: 'center',
    alignSelf: 'center',
  },
  routesText: {
    fontSize: 16,
    width: 260,
    fontWeight: '700',
    color: '#159CE4'
  }
})