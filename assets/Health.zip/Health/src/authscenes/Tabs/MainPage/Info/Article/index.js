import React from 'react'
import { View, Text, TouchableOpacity, StyleSheet, ScrollView } from 'react-native';
import BackIcon from '../../../../../../assets/images/backicon.svg';
import Line from '../../../../../../assets/images/line.svg';
import Divider from '../../../../../../assets/images/divider.svg';

export default function Article({ navigation }) {
    return (
        <View style={styles.container}>

            <View style={styles.header}>
                <TouchableOpacity
                    onPress={() => navigation.navigate("InfoTermDescription")}
                    style={styles.backView}>
                    <BackIcon />
                </TouchableOpacity>
                <View style={styles.textView}>
                    <View style={styles.textView_block}>
                        <Text style={styles.headerTitle}>
                            Сифилис
                        </Text>
                        <Line width={100} alignSelf='center' marginTop={4} />
                    </View>
                </View>
                <View style={styles.circle}>
                    <Text style={styles.circleText}></Text>
                </View>
            </View>
            <View style={styles.content}>

                <Divider marginBottom={20} />

                <ScrollView showsVerticalScrollIndicator={false} showsHorizontalScrollIndicator={false} style={styles.routesScroll}>


                    <Text style={styles.contentDescription}>
                        Американская гипотеза
                        Широко распространена гипотеза о том, что в Европу сифилис занесли матросы с кораблей Колумба из Нового Света (Америки)[6], которые, в свою очередь, заразились от аборигенов острова Гаити[7]:9. Многие из них затем присоединились к многонациональной армии короля Франции Карла VIII, который вторгся в Италию в 1494 году. В результате в 1495 году возникла вспышка сифилиса среди его солдат, когда они взяли Неаполь[8] (см. Первая итальянская война). Вероятно, это стало одной из причин ухода из завоёванного королевства Карла VIII. В 1496 году его войско было разбито испанцами, и солдаты, возвращаясь домой, способствовали распространению заболевания[7]:9. Эпидемия распространилась на Францию, Италию, Германию, Швейцарию, а затем проникла в Австрию, Венгрию, Польшу, что привело к гибели более чем 5 миллионов человек[9][10]. Считается, что основными распространителями болезни были проститутки, чьими услугами пользовались моряки и солдаты. К 1500 году эпидемия распространяется по всей Европе и выходит за её пределы, фиксируются случаи заболевания в Северной Африке, Турции, также заболевание распространяется в Юго-Восточной Азии, Китае и Индии. В 1512 году в Киото происходит большая вспышка заболеваемости сифилисом. Сифилис был основной причиной смерти в Европе в эпоху Возрождения[11].
                    </Text>


                    <Text style={styles.contentDescription}>
                        Эту гипотезу оспаривают критики, опираясь на археологические находки скелетов монахов со следами сифилитического поражения с гораздо более ранней датировкой (см. ниже). Гипотеза американского происхождения сифилиса получила новое подтверждение с помощью генетического анализа, проведённого учёными под руководством
                    </Text>

                    <Text style={styles.contentNaming}>
                        Кристин Харпер (Kristin Harper) из университета Эмори, установившими родственную связь возбудителя сифилиса — бледной трепонемы — с южноамериканскими трепонемами[12][13].
                    </Text>
                    <Text style={styles.contentDescription1}>
                        Обнаружение же средневековых скелетов со следами сифилиса учёные объясняют действием другого штамма трепонемы, пришедшего в Европу из Африки. Этот подвид болезни, по их мнению, не передавался половым путём[14][15].
                    </Text>

                </ScrollView>
            </View>
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        backgroundColor: "#E5E5E5",
        flex: 1,
    },
    header: {
        flexDirection: 'row',
        width: '90%',
        paddingTop: 50,
        justifyContent: 'space-between',
        alignSelf: 'center'
    },
    backView: {
        width: '100%',
        height: 50,
        backgroundColor: '#fff',
        alignItems: 'center',
        borderRadius: 50,
        justifyContent: 'center',
        flexGrow: 0,
        flexShrink: 1,
        flexBasis: '15%'
    },
    textView: {
        flexGrow: 1,
        flexShrink: 1,
        flexBasis: '60%',
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center'
    },
    textView_block: {
        width: '100%',
        textAlign: 'center'
    },
    circle: {
        width: '100%',
        height: 50,
        flexGrow: 0,
        flexShrink: 1,
        flexBasis: '15%',
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
    },
    circleText: {
        fontSize: 15,
        color: '#159CE4'
    },
    headerTitle: {
        width: '100%',
        fontSize: 20,
        fontWeight: 'bold',
        letterSpacing: 1,
        color: '#374957',
        textAlign: 'center',
    },
    content: {
        marginLeft: 20,
        marginTop: 20,
        width: '90%'
    },
    routesScroll: {
        width: '100%',
        marginBottom: '40%'
    },
    contentNaming: {
        fontSize: 14,
        marginVertical: 5,
        color: '#159CE4'
    },
    contentDescription: {
        fontSize: 14,
        color: '#374957',
    },
    contentDescription1: {
        fontSize: 14,
        color: '#374957',
        marginBottom: '10%'
    }
})