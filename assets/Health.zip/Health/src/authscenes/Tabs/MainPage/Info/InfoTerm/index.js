import React from 'react'
import { View, Text, TouchableOpacity, StyleSheet, TextInput } from 'react-native'
import BackIcon from '../../../../../../assets/images/backicon.svg';
import Line from '../../../../../../assets/images/line.svg';
import SearchIcon from '../../../../../../assets/images/search.svg'

import Next from '../../../../../../assets/images/next.svg'
import Divider from '../../../../../../assets/images/divider.svg'

export default function InfoTerm({navigation}) {
    return (
        <View style={styles.container}>
        <View style={styles.header}>
            <TouchableOpacity
                onPress={() =>
                    navigation.navigate('Forum')}
                style={styles.backView}>
                <BackIcon />
            </TouchableOpacity>
            <View style={styles.textView}>
                <View style={styles.textView_block}>
                    <Text style={styles.headerTitle}>
                   Информация
                    </Text>
                    <Line width={100} alignSelf='center' marginTop={4} />
                </View>
            </View>
           
        </View>
 
            <View style={styles.search}>
                <TextInput placeholder='Искать в разделе...' placeholderTextColor='#B4D1D7'/>
                 <SearchIcon/>
            </View>
            
            <View style={styles.route}>
            <TouchableOpacity style={styles.routes}
            onPress={()=>
            navigation.navigate('InfoTermDescription')}>
                   
                    <Text style={styles.routesText}>
                        ЛЖВ ТЕРМИНОЛОГИЯ
                    </Text>
                    <Next/>
            </TouchableOpacity>
            <Divider marginLeft={'10%'}/>
            <TouchableOpacity style={styles.routes}>
                
                    <Text style={styles.routesText}>
                    ЛГБТ ТЕРМИНОЛОГИЯ
                    </Text>
                    <Next/>
            </TouchableOpacity>
            <Divider marginLeft={'10%'}/>
            <TouchableOpacity style={styles.routes}>
          
                    <Text style={styles.routesText}>
                    СР ТЕРМИНОЛОГИЯ
                    </Text>
                    <Next/>
            </TouchableOpacity>
            <Divider marginLeft={'10%'}/>
            <TouchableOpacity style={styles.routes}>

                    <Text style={styles.routesText}>
                    ЛУИН ТЕРМИНОЛОГИЯ
                    </Text>
                    <Next/>
            </TouchableOpacity>
            <Divider marginLeft={'10%'}/>
            </View>
        </View>
    )
}


const styles=StyleSheet.create({
    container: {
        backgroundColor: "#E5E5E5",
        flex: 1,
        alignItems:'center',
      },
      header: {
        flexDirection: 'row',
        width: '90%',
        paddingTop: 50,
        justifyContent: 'space-between',
        alignSelf: 'center'
    },
    backView: {
        width: '100%',
        height: 50,
        backgroundColor: '#fff',
        alignItems: 'center',
        borderRadius: 50,
        justifyContent: 'center',
        flexGrow: 0,
        flexShrink: 1,
        flexBasis: '15%'
    },
    textView: {
        flexGrow: 1,
        flexShrink: 1,
        flexBasis: '60%',
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center'
    },
    textView_block: {
        width: '100%',
        textAlign: 'center'
    },
    circle: {
        width: '100%',
        height: 50,
        flexGrow: 0,
        flexShrink: 1,
        flexBasis: '15%',
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
    },
    circleText: {
        fontSize: 15,
        color: '#159CE4'
    },
    headerTitle: {
        width: '100%',
        fontSize: 20,
        fontWeight: 'bold',
        letterSpacing: 1,
        color: '#374957',
        textAlign: 'center',
    },
    search:{
        backgroundColor: '#ffffff',
        width: '90%',
        height: 50,
        borderRadius: 100,
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignSelf: 'center',
        alignItems: 'center',
        paddingHorizontal: 20,
        marginTop: 40
    },
    route: {
        height: '60%',
        marginTop: '10%',
       justifyContent: 'space-between'
    },
    routes: {
        flexDirection: 'row', 
        width: '80%',
        height: 70,
        alignItems: 'center',
        alignSelf: 'center',
        justifyContent: 'space-between',
        marginLeft: '10%',
    },
    routesText: {
        width: 240,
        marginLeft: 10,
        fontWeight: 'bold',
        color: '#159CE4'
    }
})