import React from 'react'
import { View, Text, TouchableOpacity, StyleSheet, ScrollView } from 'react-native';
import BackIcon from '../../../../../../assets/images/backicon.svg';
import Line from '../../../../../../assets/images/line.svg';
import Divider from '../../../../../../assets/images/divider.svg';

export default function InfoTermDescription({ navigation }) {
    return (
        <View style={styles.container}>

            <View style={styles.header}>
                <TouchableOpacity
                    onPress={() => navigation.navigate("InfoTerm")}
                    style={styles.backView}>
                    <BackIcon />
                </TouchableOpacity>
                <View style={styles.textView}>
                    <View style={styles.textView_block}>
                        <Text style={styles.headerTitle}>
                            ЛЖВ терминология
                        </Text>
                        <Line width={100} alignSelf='center' marginTop={4} />
                    </View>
                </View>
                <View style={styles.circle}>
                    <Text style={styles.circleText}></Text>
                </View>
            </View>
            <View style={styles.content}>
                <Text style={styles.description}>
                    КРАТКОЕ ОПИСАНИЕ ПРЕДПОЧТИТЕЛЬНЫХ ТЕРМИНОВ И ОШИБОК, КОТОРЫХ СЛЕДУБЕТ ИЩБЕГАТЬ
                </Text>
                <Divider />

                <ScrollView
                    showsVerticalScrollIndicator={false} showsHorizontalScrollIndicator={false}
                    style={styles.routesScroll}>
                    <TouchableOpacity onPress={() => navigation.navigate('Article')}>
                        <Text style={styles.contentNaming}>
                            ВИЧ/СПИД; ВИЧ и СПИД
                        </Text></TouchableOpacity>
                    <Text style={styles.contentDescription}>
                        Используйте термин, являющийся наиболее точным и подходящим в соответствующем
                        контексте, чтобы избежать путаницы между ВИЧ (вирусом) и СПИДом (клиническим синдромом).
                        Примеры включают: «люди, живущие с ВИЧ», «распространенность ВИЧ», «профилактика ВИЧ»,
                        «тестирование на ВИЧ и консультирование по вопросам ВИЧ», «заболевание, связанное с ВИЧ»,
                        «диагноз СПИД», «дети, осиротевшие в результате СПИДа», «меры в ответ на СПИД», «национальная
                        программа мер в ответ на СПИД», «СПИД-сервисные организации». Допустимо употребление обоих
                        терминов: «эпидемия ВИЧ» и «эпидемия СПИДа» (но «эпидемия ВИЧ» является более широким
                        термином).
                    </Text>
                    <TouchableOpacity onPress={() => navigation.navigate('Article')}>
                        <Text style={styles.contentNaming}>
                            Вирус СПИДа
                        </Text>
                    </TouchableOpacity>


                    <Text style={styles.contentDescription}>
                        Вируса СПИДа не существует. Вирус, который вызывает СПИД, называется вирусом иммунодефицита человека (ВИЧ).
                    </Text>

                    <TouchableOpacity onPress={() => navigation.navigate('Article')}>
                        <Text style={styles.contentNaming}>
                            ВИЧ/СПИД; ВИЧ и СПИД
                        </Text>
                    </TouchableOpacity>


                    <Text style={styles.contentDescription1}>
                        Используйте термин, являющийся наиболее точным и подходящим в соответствующем
                        контексте, чтобы избежать путаницы между ВИЧ (вирусом) и СПИДом (клиническим синдромом).
                        Примеры включают: «люди, живущие с ВИЧ», «распространенность ВИЧ», «профилактика ВИЧ»,
                        «тестирование на ВИЧ и консультирование по вопросам ВИЧ», «заболевание, связанное с ВИЧ»,
                        «диагноз СПИД», «дети, осиротевшие в результате СПИДа», «меры в ответ на СПИД», «национальная
                        программа мер в ответ на СПИД», «СПИД-сервисные организации». Допустимо употребление обоих
                        терминов: «эпидемия ВИЧ» и «эпидемия СПИДа» (но «эпидемия ВИЧ» является более широким
                        термином).
                    </Text>
                </ScrollView>
            </View>
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        backgroundColor: "#E5E5E5",
        flex: 1,
    },
    header: {
        flexDirection: 'row',
        width: '90%',
        paddingTop: 50,
        justifyContent: 'space-between',
        alignSelf: 'center'
    },
    backView: {
        width: '100%',
        height: 50,
        backgroundColor: '#fff',
        alignItems: 'center',
        borderRadius: 50,
        justifyContent: 'center',
        flexGrow: 0,
        flexShrink: 1,
        flexBasis: '15%'
    },
    textView: {
        flexGrow: 1,
        flexShrink: 1,
        flexBasis: '60%',
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center'
    },
    textView_block: {
        width: '100%',
        textAlign: 'center'
    },
    circle: {
        width: '100%',
        height: 50,
        flexGrow: 0,
        flexShrink: 1,
        flexBasis: '15%',
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
    },
    circleText: {
        fontSize: 15,
        color: '#159CE4'
    },
    headerTitle: {
        width: '100%',
        fontSize: 20,
        fontWeight: 'bold',
        letterSpacing: 1,
        color: '#374957',
        textAlign: 'center',
    },
    content: {
        marginLeft: 20,
        marginTop: 20,
        width: '90%'
    },
    description: {
        fontWeight: 'bold',
        fontSize: 12,
        marginBottom: 10
    },
    routesScroll: {
        width: '100%',
        marginBottom: '40%'
    },
    contentNaming: {
        fontWeight: 'bold',
        fontSize: 14,
        marginVertical: 10,
        color: '#374957'
    },
    contentDescription: {
        fontSize: 12,
        color: '#374957',
        marginBottom: '1%'
    },
    contentDescription1: {
        fontSize: 12,
        color: '#374957',
        marginBottom: '30%'
    }
})