import React, { useState } from 'react'
import { ScrollView, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import PillsComp from './PillsComp';
import BackIcon from '../../../../../assets/images/backicon.svg';
import Line from '../../../../../assets/images/line.svg';

export default function Pills({ navigation }) {
  const [btn, setBtn] = useState(false)


  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity
          onPress={() => navigation.navigate("MainPage")}
          style={styles.backView}>
          <BackIcon />
        </TouchableOpacity>
        <View style={styles.textView}>
          <View style={styles.textView_block}>
            <Text style={styles.headerTitle}>
              Прием лекарств
            </Text>
            <Line width={100} alignSelf='center' marginTop={4} />
          </View>
        </View>
        <View style={styles.circle}>
        </View>
      </View>

      <ScrollView
        showsVerticalScrollIndicator={false} showsHorizontalScrollIndicator={false}
        style={styles.content}>
        <View  >
          <PillsComp
            enable={true}
          />
          <PillsComp
            enable={false}
          />
          <PillsComp
            enable={true}
          />
        </View>
      </ScrollView>

      <View style={styles.buttons}>
        <TouchableOpacity
          onPress={
            () => {
              setBtn(!btn);
              setTimeout(() => navigation.navigate('PillsAdd'), 1000);
            }}
          style={btn ? styles.buttonstyle2 : styles.buttonstyle1

          }>

          <Text style={btn ? styles.textbutton2 : styles.textbutton1}>Добавить еще</Text>

        </TouchableOpacity>
      </View>



    </View>
  )
}

const styles = StyleSheet.create({
  btn: {
    width: '100%',
    alignItems: 'center',
    marginTop: '160%',

  },
  container: {
    flex: 1,
    backgroundColor: "#E5E5E5",
  },
  header: {
    flexDirection: 'row',
    width: '90%',
    paddingTop: '13%',
    justifyContent: 'space-between',
    alignSelf: 'center',
    marginBottom: 40
  },
  backView: {
    width: '100%',
    height: 50,
    backgroundColor: '#fff',
    alignItems: 'center',
    borderRadius: 50,
    justifyContent: 'center',
    flexGrow: 0,
    flexShrink: 1,
    flexBasis: '15%'
  },
  textView: {
    flexGrow: 1,
    flexShrink: 1,
    flexBasis: '60%',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center'
  },
  textView_block: {
    width: '100%',
    textAlign: 'center'
  },
  circle: {
    width: '100%',
    height: 50,
    flexGrow: 0,
    flexShrink: 1,
    flexBasis: '15%',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: 'transparent',
    borderRadius: 50
  },
  headerTitle: {
    width: '100%',
    fontSize: 20,
    fontWeight: 'bold',
    letterSpacing: 1,
    color: '#374957',
    textAlign: 'center',
  },

  headerText: {
    fontSize: 20,
    fontWeight: "700",
    marginTop: 6,
    letterSpacing: 0.4,
    alignSelf: 'center',
  },
  hederLine: {
    alignSelf: "center",
    marginTop: 4,
  },
  content: {
    width: '100%',
    marginTop: '2%',
    height: '70%'
  },
  buttons: {
    width: '80%',
    marginTop: '5%',
    marginLeft: '15%',
    marginBottom: '20%'
  },

  buttonstyle1: {
    borderColor: "#159CE4",
    borderWidth: 2,
    width: '80%',
    height: 45,
    borderRadius: 20,
    alignContent: "center",
    justifyContent: "center",
  },
  textbutton1: {
    color: "black",
    fontSize: 15,
    textAlign: "center",
  },
  buttonstyle2: {
    backgroundColor: "#159CE4",
    borderColor: "#159CE4",
    borderWidth: 2,
    width: '80%',
    height: 45,
    borderRadius: 20,
    alignContent: "center",
    justifyContent: "center",
  },
  textbutton2: {
    color: "white",
    fontSize: 15,
    textAlign: "center",
  },

});

