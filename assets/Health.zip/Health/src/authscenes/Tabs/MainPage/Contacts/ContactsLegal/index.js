import React from 'react'
import { View, Text, TouchableOpacity, StyleSheet, ScrollView, Image } from 'react-native'
import MapView, { Marker, PROVIDER_GOOGLE } from 'react-native-maps';
import BackIcon from '../../../../../../assets/images/backicon.svg';
import Line from '../../../../../../assets/images/line.svg';
import map from '../../../../../../assets/images/map2.png';


const ContactsLegal = ({ navigation }) => {
    return (
        <View style={styles.container}>
            <View style={styles.header}>
                <TouchableOpacity
                    onPress={() =>
                        navigation.navigate('Contacts')}
                    style={styles.backView}>
                    <BackIcon />
                </TouchableOpacity>
                <View style={styles.textView}>
                    <View style={styles.textView_block}>
                        <Text style={styles.headerTitle}>
                            Юридические контакты
                        </Text>
                        <Line width={100} alignSelf='center' marginTop={4} />
                    </View>
                </View>
            </View>

            <View style={styles.content}>

                <Image width={'100%'} height={200} source={map} />

                <ScrollView showsVerticalScrollIndicator={false} showsHorizontalScrollIndicator={false}>

                    <View style={styles.contentText}>

                        <View style={styles.contText}>
                            <Text style={{ fontWeight: '700', fontSize: 16, }}>
                                ЗАО "Юридическая фирма "Клифф"
                            </Text>
                            <Text style={{ fontWeight: '400', fontSize: 16, }}>
                                Кутузовский просп., 36с3, Москва, Россия, 121170
                                +7 495 504-34-61
                            </Text>
                            <View style={{ width: '94%', height: 1, backgroundColor: 'silver', marginTop: 15, }}></View>
                        </View>
                        <View style={styles.contText}>
                            <Text style={{ fontWeight: '700', fontSize: 16, }}>
                                ЗАО "Юридическая фирма "Клифф"
                            </Text>
                            <Text style={{ fontWeight: '400', fontSize: 16, }}>
                                Кутузовский просп., 36с3, Москва, Россия, 121170
                                +7 495 504-34-61
                            </Text>
                            <View style={{ width: '94%', height: 1, backgroundColor: 'silver', marginTop: 15, }}></View>
                        </View>
                        <View style={styles.contText}>
                            <Text style={{ fontWeight: '700', fontSize: 16, }}>
                                ЗАО "Юридическая фирма "Клифф"
                            </Text>
                            <Text style={{ fontWeight: '400', fontSize: 16, }}>
                                Кутузовский просп., 36с3, Москва, Россия, 121170
                                +7 495 504-34-61
                            </Text>
                            <View style={{ width: '94%', height: 1, backgroundColor: 'silver', marginTop: 15, }}></View>
                        </View>
                        <View style={styles.contText}>
                            <Text style={{ fontWeight: '700', fontSize: 16, }}>
                                ЗАО "Юридическая фирма "Клифф"
                            </Text>
                            <Text style={{ fontWeight: '400', fontSize: 16, }}>
                                Кутузовский просп., 36с3, Москва, Россия, 121170
                                +7 495 504-34-61
                            </Text>
                            <View style={{ width: '94%', height: 1, backgroundColor: 'silver', marginTop: 15, }}></View>
                        </View>



                    </View>
                </ScrollView>
            </View>
        </View>
    )
}

const styles = StyleSheet.create({
    contText: {
        width: '100%',
        marginTop: '5%',

    },
    contentText: {
        width: '94%',
        marginTop: 20,
        paddingBottom: 50,
        // alignItems: 'center',
        height: 720,
    },
    mapView: {
        width: '100%',
        height: 200,

    },
    container: {
        backgroundColor: "#E5E5E5",
        flex: 1,
    },
    header: {
        flexDirection: 'row',
        width: '90%',
        paddingTop: 50,
        justifyContent: 'space-between',
        alignSelf: 'center'
    },
    backView: {
        width: '100%',
        height: 50,
        backgroundColor: '#fff',
        alignItems: 'center',
        borderRadius: 50,
        justifyContent: 'center',
        flexGrow: 0,
        flexShrink: 1,
        flexBasis: '15%'
    },
    backView: {
        width: '100%',
        height: 50,
        backgroundColor: '#fff',
        alignItems: 'center',
        borderRadius: 50,
        justifyContent: 'center',
        flexGrow: 0,
        flexShrink: 1,
        flexBasis: '15%'
    },
    textView: {
        flexGrow: 1,
        flexShrink: 1,
        flexBasis: '60%',
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center'
    },
    textView_block: {
        width: '100%',
        textAlign: 'center'
    },
    headerTitle: {
        width: '100%',
        fontSize: 20,
        fontWeight: 'bold',
        letterSpacing: 1,
        color: '#374957',
        textAlign: 'center',
    },
    content: {
        width: '100%',
        marginTop: 30,
        alignItems: 'center',
    },
})

export default ContactsLegal
