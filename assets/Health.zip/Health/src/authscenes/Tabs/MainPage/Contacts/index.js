import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView } from 'react-native';
import BackIcon from '../../../../../assets/images/backicon.svg';
import Line from '../../../../../assets/images/line.svg';
import Next from '../../../../../assets/images/next.svg';
import Divider from '../../../../../assets/images/divider.svg';
import Tabs from '../..';

export default function Contacts({navigation}) {
    return (
        <View style={styles.container}>

        <View style={styles.header}>
                <TouchableOpacity
                                    onPress={() => navigation.navigate("MainPage")}
                    style={styles.backView}>
                    <BackIcon />
                </TouchableOpacity>
                <View style={styles.textView}>
                    <View style={styles.textView_block}>
                        <Text style={styles.headerTitle}>
                        Контакты
                        </Text>
                        <Line width={100} alignSelf='center' marginTop={4} />
                    </View>
                </View>
                <View style={styles.circle}>
                    <Text style={styles.circleText}></Text>
                </View>
        </View>
        

        <View style={styles.route}>

            <TouchableOpacity style={styles.routes}
            onPress={()=>
            navigation.navigate('ContactsLegal')}>
                   
                    <Text style={styles.routesText}>
                        ЮРИДИЧЕСКИЕ КОНТАКТЫ
                    </Text>
                    <Next/>
            </TouchableOpacity>
            <View style={{ width: '90%', backgroundColor: 'silver', height: 1,  marginLeft:'5%'}}></View>
            <TouchableOpacity style={styles.routes}>
                
                    <Text style={styles.routesText}>
                    МЕДИЦИНСКИЕ КОНТАКТЫ
                    </Text>
                    <Next/>
            </TouchableOpacity>
            <View style={{ width: '90%', backgroundColor: 'silver', height: 1,  marginLeft:'5%'}}></View>
            <TouchableOpacity style={styles.routes}>
          
                    <Text style={styles.routesText}>
                    СОЦИАЛЬНЫЕ КОНТАКТЫ
                    </Text>
                    <Next/>
            </TouchableOpacity>
            <View style={{ width: '90%', backgroundColor: 'silver', height: 1,  marginLeft:'5%'}}></View>
            <TouchableOpacity style={styles.routes}>

                    <Text style={styles.routesText}>
                    ОРГАНИЗАЦИОННЫЕ КОНТАКТЫ
                    </Text>
                    <Next/>
            </TouchableOpacity>
            <View style={{ width: '90%', backgroundColor: 'silver', height: 1,  marginLeft:'5%'}}></View>
            <TouchableOpacity style={styles.routes}
            onPress={()=>
            navigation.navigate('ContactsReview')}>

                    <Text style={styles.routesText}>
                    ОБРАТНАЯ СВЯЗЬ
                    </Text>
                    <Next/>
            </TouchableOpacity>
            <View style={{ width: '90%', backgroundColor: 'silver', height: 1,  marginLeft:'5%'}}></View>
            <TouchableOpacity style={styles.routes}
            onPress={()=>
            navigation.navigate('ContactsMap')}>

                    <Text style={styles.routesText}>
                    МЫ НА КАРТЕ
                    </Text>
                    <Next/>
            </TouchableOpacity>
            <View style={{ width: '90%', backgroundColor: 'silver', height: 1,  marginLeft:'5%'}}></View>
           
        </View>
    </View>
    )
}

const styles=StyleSheet.create({
    container: {
        backgroundColor: "#E5E5E5",
        flex: 1,
    },
    header: {
        flexDirection: 'row',
        width: '90%',
        paddingTop: 50,
        justifyContent: 'space-between',
        alignSelf: 'center'
    },
    backView: {
        width: '100%',
        height: 50,
        backgroundColor: '#fff',
        alignItems: 'center',
        borderRadius: 50,
        justifyContent: 'center',
        flexGrow: 0,
        flexShrink: 1,
        flexBasis: '15%'
    },
    textView: {
        flexGrow: 1,
        flexShrink: 1,
        flexBasis: '60%',
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center'
    },
    textView_block: {
        width: '100%',
        textAlign: 'center'
    },
    circle: {
        width: '100%',
        height: 50,
        flexGrow: 0,
        flexShrink: 1,
        flexBasis: '15%',
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
    },
    circleText: {
        fontSize: 15,
        color: '#159CE4'
    },
    headerTitle: {
        width: '100%',
        fontSize: 20,
        fontWeight: 'bold',
        letterSpacing: 1,
        color: '#374957',
        textAlign: 'center',
    },
    route: {
        height: '60%',
        marginTop: '10%',
       justifyContent: 'space-between'
    },
    routes: {
        flexDirection: 'row', 
        width: '85%',
        height: 70,
        alignItems: 'center',
        alignSelf: 'center',
        justifyContent: 'space-between'
    },
    routesText: {
        width: 260,
        marginLeft: 10,
        fontWeight: 'bold',
        color: '#159CE4'
    }
})