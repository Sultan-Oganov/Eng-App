import React, { useState } from 'react'
import { StyleSheet, Text, View, Switch, Platform, Image, TouchableOpacity } from "react-native";



export default function Adding({ enable }) {
  const [state1, setState1] = useState(false);
  const [state2, setState2] = useState(false);
  const [state3, setState3] = useState(false);
  const [state4, setState4] = useState(false);
  const [state5, setState5] = useState(false);
  const [state6, setState6] = useState(false);
  const [state7, setState7] = useState(false);
  const [enabled, setEnabled] = useState(enable);
  const toggleSwitch = () => {
    setEnabled((oldValue) => !oldValue);
  };

  const thumbColorOn = Platform.OS === "android" ? "#fff" : "#fff";
  const thumbColorOff = Platform.OS === "android" ? "#fff" : "#fff";
  const trackColorOn = Platform.OS === "android" ? "#98e7f0" : "#0cd1e8";
  const trackColorOff = Platform.OS === "android" ? "#EAF1FF" : "#EAF1FF";
  return (
    <View style={enabled ? styles.container1 : styles.container}>

      <View style={styles.content}>
        <View style={{ marginLeft: 10, height: '100%', flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
          {
            enabled ? <Text style={{ fontSize: 14, fontWeight: '700', color: 'black', }} >
              Eжедневно
            </Text>
              :
              <Text style={{ fontSize: 14, fontWeight: '700', color: 'black', }} >
                Выберите дни
              </Text>
          }

        </View>
        <Switch
          onValueChange={toggleSwitch}
          value={enabled}
          thumbColor={enabled ? thumbColorOn : thumbColorOff}
          trackColor={{ false: trackColorOff, true: trackColorOn }}
          ios_backgroundColor={trackColorOff}
        />
      </View>


      {enabled ?
        null
        :
        <View style={styles.buttons}>


          <TouchableOpacity
            onPress={() => {
              setState1(!state1);
            }}
            style={state1 ? styles.buttonstyle2 : styles.buttonstyle1}
          >
            <Text style={state1 ? styles.textbutton2 : styles.textbutton1}>Пн {state1 ? <Text style={{ fontWeight: '700', fontSize: 16 }}>x</Text> : null}</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => {
            setState2(!state2);
          }}
            style={state2 ? styles.buttonstyle2 : styles.buttonstyle1}>
            <Text style={state2 ? styles.textbutton2 : styles.textbutton1}>Вт  {state2 ? <Text style={{ fontWeight: '700', fontSize: 16 }}>x</Text> : null}</Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => {
              setState3(!state3);
            }}
            style={state3 ? styles.buttonstyle2 : styles.buttonstyle1}
          >
            <Text style={state3 ? styles.textbutton2 : styles.textbutton1}>Ср  {state3 ? <Text style={{ fontWeight: '700', fontSize: 16 }}>x</Text> : null}</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => {
            setState4(!state4);
          }}
            style={state4 ? styles.buttonstyle2 : styles.buttonstyle1}>
            <Text style={state4 ? styles.textbutton2 : styles.textbutton1}>Чт  {state4 ? <Text style={{ fontWeight: '700', fontSize: 16 }}>x</Text> : null}</Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => {
              setState5(!state5);
            }}
            style={state5 ? styles.buttonstyle2 : styles.buttonstyle1}
          >
            <Text style={state5 ? styles.textbutton2 : styles.textbutton1}>Пт  {state5 ? <Text style={{ fontWeight: '700', fontSize: 16 }}>x</Text> : null}</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => {
            setState6(!state6);
          }}
            style={state6 ? styles.buttonstyle2 : styles.buttonstyle1}>
            <Text style={state6 ? styles.textbutton2 : styles.textbutton1}>Сб  {state6 ? <Text style={{ fontWeight: '700', fontSize: 16 }}>x</Text> : null}</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => {
            setState7(!state7);
          }}
            style={state7 ? styles.buttonstyle2 : styles.buttonstyle1}>
            <Text style={state7 ? styles.textbutton2 : styles.textbutton1}>Вс  {state7 ? <Text style={{ fontWeight: '700', fontSize: 16 }}>x</Text> : null}</Text>
          </TouchableOpacity>

        </View>
      }



    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    width: '94%',
    backgroundColor: 'white',
    marginTop: '5%',
    marginBottom: '2%',
    marginLeft: 10,
    height: 150,
    flexDirection: 'column',
    justifyContent: 'center',
    borderRadius: 20,
    shadowOffset: {
      width: 1,
      height: 2,
    },
    shadowOpacity: 0.35,
    shadowRadius: 5,
    shadowColor:'#159CE4',
    elevation: 5,
  },
  container1: {
    width: '94%',
    backgroundColor: 'white',
    marginTop: '5%',
    marginBottom: '2%',
    marginLeft: 10,
    height: 60,
    flexDirection: 'column',
    justifyContent: 'center',
    borderRadius: 20,
    shadowOffset: {
      width: 1,
      height: 2,
    },
    shadowOpacity: 0.35,
    shadowRadius: 5,
    shadowColor:'#159CE4',
    elevation: 5,
  },
  content: {
    width: '90%',
    height: 20,
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginLeft: '5%',
  },
  buttons: {
    width: '90%',
    height: 100,
    flexWrap: 'wrap',
    marginTop: '2%',
    marginLeft: '5%',
  },

  buttonstyle1: {
    backgroundColor: '#EAF1FF',
    borderWidth: 2,
    width: 60,
    height: 30,
    borderRadius: 20,
    alignContent: "center",
    justifyContent: "center",
    borderColor: '#EAF1FF',
    marginLeft: 10,
    marginTop: '5%',
  },
  textbutton1: {
    color: "black",
    fontSize: 12,
    textAlign: "center",
  },
  buttonstyle2: {
    backgroundColor: "#159CE4",
    borderColor: "#159CE4",
    borderWidth: 2,
    width: 60,
    height: 30,
    borderRadius: 20,
    alignContent: "center",
    justifyContent: "center",
    marginLeft: 10,
    marginTop: '5%',
  },
  textbutton2: {
    color: "white",
    fontSize: 12,
    textAlign: "center",
  },
});
