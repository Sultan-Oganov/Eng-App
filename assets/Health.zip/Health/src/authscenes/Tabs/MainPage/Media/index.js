import React from 'react'
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native'
import BackIcon from '../../../../../assets/images/backicon.svg';
import Line from '../../../../../assets/images/line.svg';
import Media1 from '../../../../../assets/images/media1'
import Media2 from '../../../../../assets/images/media2';
import Media3 from '../../../../../assets/images/media3';
import Media4 from '../../../../../assets/images/media4';
import Media5 from '../../../../../assets/images/media5';
import Media6 from '../../../../../assets/images/media6'

export default function Media({ navigation }) {
    return (
        <View style={styles.container}>
            <View style={styles.header}>
                <TouchableOpacity
                                    onPress={() => navigation.navigate("MainPage")}
                    style={styles.backView}>
                    <BackIcon />
                </TouchableOpacity>
                <View style={styles.textView}>
                    <View style={styles.textView_block}>
                        <Text style={styles.headerTitle}>
                        Медиа
                        </Text>
                        <Line width={100} alignSelf='center' marginTop={4} />
                    </View>
                </View>
                <View style={styles.circle}>
                    <Text style={styles.circleText}></Text>
                </View>
        </View>

            <View style={styles.media}>
                <View style={styles.mediaFiles}>
                <TouchableOpacity
                    onPress={()=>
                    navigation.navigate('MediaVideo')}>
                    <Media1 width={150}/>
                </TouchableOpacity>
                <TouchableOpacity>
                    <Media2 width={150}/>
                </TouchableOpacity>
                </View>
                <View style={styles.mediaFiles}>
                <TouchableOpacity>
                    <Media3 width={150}/>
                </TouchableOpacity>
                <TouchableOpacity>
                    <Media4 width={150}/>
                </TouchableOpacity>
                </View>
                <View style={styles.mediaFiles}>
                <TouchableOpacity>
                    <Media5 width={150}/>
                </TouchableOpacity>
                <TouchableOpacity>
                    <Media6 width={150}/>
                </TouchableOpacity>
                </View>
            </View>
        </View>
    )
}


const styles = StyleSheet.create({
    container: {
        backgroundColor: "#E5E5E5",
        flex: 1,
    },
    header: {
        flexDirection: 'row',
        width: '90%',
        paddingTop: 50,
        justifyContent: 'space-between',
        alignSelf: 'center'
    },
    backView: {
        width: '100%',
        height: 50,
        backgroundColor: '#fff',
        alignItems: 'center',
        borderRadius: 50,
        justifyContent: 'center',
        flexGrow: 0,
        flexShrink: 1,
        flexBasis: '15%'
    },
    textView: {
        flexGrow: 1,
        flexShrink: 1,
        flexBasis: '60%',
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center'
    },
    textView_block: {
        width: '100%',
        textAlign: 'center'
    },
    circle: {
        width: '100%',
        height: 50,
        flexGrow: 0,
        flexShrink: 1,
        flexBasis: '15%',
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
    },
    circleText: {
        fontSize: 15,
        color: '#159CE4'
    },
    headerTitle: {
        width: '100%',
        fontSize: 20,
        fontWeight: 'bold',
        letterSpacing: 1,
        color: '#374957',
        textAlign: 'center',
    },
    media: {
        marginTop: '10%'
    },
    mediaFiles: {
        flexDirection: 'row',
        justifyContent: 'space-around',
        width: '90%',
        alignSelf: 'center'
    }
})