import React, { useState } from 'react'
import { View, Text, TouchableOpacity, StyleSheet, Dimensions } from 'react-native';
// import * as ScreenOrientation from 'expo-screen-orientation';
import VideoPlayer from 'expo-video-player';
import { setStatusBarHidden } from 'expo-status-bar'
import { Video } from 'expo-av';
import BackIcon from '../../../../../../assets/images/backicon.svg';
import Line from '../../../../../../assets/images/line.svg';

export default function MediaVideo({ navigation }) {
    const [inFullscreen2, setInFullsreen2] = useState(false)

    return (
        <View style={styles.container}>
            <View style={styles.header}>
                <TouchableOpacity
                    onPress={() => navigation.navigate("Media")}
                    style={styles.backView}>
                    <BackIcon />
                </TouchableOpacity>
                <View style={styles.textView}>
                    <View style={styles.textView_block}>
                        <Text style={styles.headerTitle}>
                            Гонорея
                        </Text>
                        <Line width={100} alignSelf='center' marginTop={4} />
                    </View>
                </View>
                <View style={styles.circle}>
                    <Text style={styles.circleText}></Text>
                </View>
            </View>


            <View style={styles.video}>

                <VideoPlayer
                    // style={{height: 211}}
                    videoProps={{
                        shouldPlay: true,
                        resizeMode: Video.RESIZE_MODE_CONTAIN,
                        // ❗ source is required https://docs.expo.io/versions/latest/sdk/video/#props
                        source: {
                            uri: 'http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
                        }
                    }}
                    fullscreen={{
                        inFullscreen: inFullscreen2,
                        enterFullscreen: async () => {
                            setStatusBarHidden(true, 'fade')
                            setInFullsreen2(!inFullscreen2)
                            await ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.LANDSCAPE_LEFT)
                            refVideo2.current.setStatusAsync({
                                shouldPlay: true,
                            })
                        },
                        exitFullscreen: async () => {
                            setStatusBarHidden(false, 'fade')
                            setInFullsreen2(!inFullscreen2)
                            await ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.DEFAULT)
                        },
                    }}

                    style={{
                        videoBackgroundColor: 'transparent',
                        height: inFullscreen2 ? 240 : 240,
                        width: inFullscreen2 ? 640 : 440,
                    }}
                />
            </View>

            <View style={styles.mediaDescription}>
                <Text style={styles.mediaTitle}>
                    Краткое описание предпочтительных терминов и ошибок, которых следует избегать
                </Text>
                <Text style={styles.mediaSubTitle}>
                    Вируса СПИДа не существует. Вирус, который вызывает СПИД, называется вирусом иммунодефицита человека (ВИЧ).
                </Text>
            </View>

        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        backgroundColor: "#E5E5E5",
        flex: 1,
        alignItems: 'center',
    },
    header: {
        flexDirection: 'row',
        width: '90%',
        paddingTop: 50,
        justifyContent: 'space-between',
        alignSelf: 'center'
    },
    backView: {
        width: '100%',
        height: 50,
        backgroundColor: '#fff',
        alignItems: 'center',
        borderRadius: 50,
        justifyContent: 'center',
        flexGrow: 0,
        flexShrink: 1,
        flexBasis: '15%'
    },
    textView: {
        flexGrow: 1,
        flexShrink: 1,
        flexBasis: '60%',
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center'
    },
    textView_block: {
        width: '100%',
        textAlign: 'center'
    },
    circle: {
        width: '100%',
        height: 50,
        flexGrow: 0,
        flexShrink: 1,
        flexBasis: '15%',
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
    },
    circleText: {
        fontSize: 15,
        color: '#159CE4'
    },
    headerTitle: {
        width: '100%',
        fontSize: 20,
        fontWeight: 'bold',
        letterSpacing: 1,
        color: '#374957',
        textAlign: 'center',
    },
    mediaDescription: {
        width: '90%',
        alignSelf: 'center',
        marginTop: '6%'
    },
    mediaTitle: {
        fontSize: 14,
        fontWeight: 'bold'
    },
    mediaSubTitle: {
        marginTop: '4%'
    },
    video: {
        width: '100%',
        // height: '50%',
        marginTop: '5%'

    }
})