import React from 'react'
import { useNavigation } from "@react-navigation/native";
import { View, Text, TouchableOpacity, StyleSheet, TextInput, Image } from 'react-native'
import ShareImage from '../../../../../assets/images/share.png';
import Logo from '../../../../../assets/images/logo.svg';
import Naming from '../../../../../assets/images/naming.svg';
import Tabs from '../..';


export default function Share() {
    const navigation = useNavigation()
    return (
        <View style={styles.container}>
            <View style={{width:'100%',marginTop:'35%', }}>
                <Logo width={150} alignSelf='center'/>
                <Naming width={150} alignSelf='center' style={{marginTop:5,}} />
            </View>
            
            <TouchableOpacity
            onPress={()=>
            navigation.navigate('MainPage')}
            style={styles.button}>

            <Image source={ShareImage} style={{alignItems: 'center',marginLeft:'5%',marginTop:'4%', width:25,}}/>
            
            <Text style={styles.buttonText}>Поделиться ссылкой с друзьями</Text>

        </TouchableOpacity>
        </View> 
    )
}

const styles = StyleSheet.create({
    container:{
        backgroundColor: "#E5E5E5",
        flex: 1,
        flexDirection: 'column',
        paddingVertical: 100,
        alignItems: 'center'
    },
    button:{
        backgroundColor: '#159CE4',
        marginTop: '10%',
        flexDirection:'row',
        width: '90%',
        height:55,
        borderRadius: 20,
    },
    buttonText:{
        fontSize: 15,
        fontWeight: '600',
        color: '#ffffff',
        alignSelf: 'center',
        marginLeft: '10%',
        
    },
})


