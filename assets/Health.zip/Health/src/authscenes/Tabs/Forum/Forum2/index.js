import React, { useState } from 'react'
import { useNavigation } from "@react-navigation/native";
import { View, Text, TouchableOpacity, StyleSheet, ScrollView, TextInput } from 'react-native'
import BackIcon from '../../../../../assets/images/backicon.svg'
import Add from '../../../../../assets/images/plus.svg';
import Line from '../../../../../assets/images/line.svg';
import UserB from '../../../../../assets/images/user-black.svg';
import UserW from '../../../../../assets/images/user-white.svg';
import Tabs from '../..';

export default function Forum2() {
    const navigation = useNavigation()
    const [changePost, setChangePost] = useState(false)
    return (
        <View style={styles.container}>
            <View style={styles.header}>
                <TouchableOpacity
                    onPress={() =>
                        navigation.navigate('Forum')}
                    style={styles.backView}>
                    <BackIcon />
                </TouchableOpacity>
                <View style={styles.textView}>
                    <View style={styles.textView_block}>
                        <Text style={styles.headerTitle}>
                            Форум
                        </Text>
                        <Line width={100} alignSelf='center' marginTop={4} />
                    </View>
                </View>
                <View style={styles.circle}>
                    <Text style={styles.circleText}>3</Text>
                </View>
            </View>


            <ScrollView showsVerticalScrollIndicator={false} showsHorizontalScrollIndicator={false}>
                <View style={styles.content}>

                    <View style={styles.detail}>
                        <Text style={styles.detail__title}>Хирург забыл в полости веник :( Что делать?</Text>
                        <Text style={styles.detail__description}>Примеры включают: «люди, живущие с ВИЧ», «распространенность ВИЧ», «профилактика ВИЧ»,
                            «тестирование на ВИЧ и консультирование по вопросам ВИЧ», «заболевание, связанное с ВИЧ»,
                            «диагноз СПИД», «дети, осиротевшие в результате СПИДа», «меры в ответ на СПИД», «национальная
                            программа мер в ответ на СПИД», «СПИД-сервисные организации». Допустимо употребление обоих
                            терминов: «эпидемия ВИЧ» и «эпидемия СПИДа» (но «эпидемия ВИЧ» является более широким
                            термином).
                        </Text>
                        <View style={styles.detail__info}>
                            <View style={styles.detail__comment}>
                                <Text style={styles.detail__text}>
                                    Комментариев: 125
                                    (<Text style={styles.comment__blue}>Ваших: 3</Text>)
                                </Text>
                                <Text style={styles.detail__text}>
                                    Автор: Nickname       Дата: 12.08.21  16:36
                                </Text>
                            </View>

                            <View style={styles.detail__btnAdd}>
                                <TouchableOpacity><Add /></TouchableOpacity>
                            </View>
                        </View>

                        <View style={styles.detail__users}>
                            {/* <ScrollView> */}
                            <View style={styles.user}>
                                <View style={styles.user__logo}>
                                    <UserB />
                                </View>
                                <View style={styles.user__descr}>
                                    <Text style={styles.user__text}><Text style={styles.user__name}>Nickname</Text>         Дата: 12.08.21  16:36</Text>
                                    <Text style={styles.user__text}>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. </Text>
                                    <TouchableOpacity style={styles.user__link}><Text style={styles.user__link_text}>Ответить</Text></TouchableOpacity>
                                </View>
                            </View>

                            <View style={styles.user}>
                                <View style={styles.user__logo}>
                                    <UserB />
                                </View>
                                <View style={styles.user__descr}>
                                    <Text style={styles.user__text}><Text style={styles.user__name}>Nickname</Text>         Дата: 12.08.21  16:36</Text>
                                    <Text style={styles.user__text}>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. </Text>
                                    <TouchableOpacity style={styles.user__link}><Text style={styles.user__link_text}>Ответить</Text></TouchableOpacity>
                                </View>
                            </View>

                            <View style={styles.user}>
                                <View style={styles.user__logo}>
                                    <UserB />
                                </View>
                                <View style={styles.user__descr}>
                                    <Text style={styles.user__text}><Text style={styles.user__name}>Nickname</Text>         Дата: 12.08.21  16:36</Text>
                                    <Text style={styles.user__text}>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. </Text>
                                    <TouchableOpacity style={styles.user__link}><Text style={styles.user__link_text}>Ответить</Text></TouchableOpacity>
                                </View>
                            </View>

                            <View style={styles.user}>
                                <View style={styles.user__logo}>
                                    <UserB />
                                </View>
                                <View style={styles.user__descr}>
                                    <Text style={styles.user__text}><Text style={styles.user__name}>Nickname</Text>         Дата: 12.08.21  16:36</Text>
                                    <Text style={styles.user__text}>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. </Text>
                                    <TouchableOpacity style={styles.user__link}><Text style={styles.user__link_text}>Ответить</Text></TouchableOpacity>
                                </View>
                            </View>

                            <View style={styles.user__answered}>
                                <View style={styles.user}>
                                    <View style={[styles.user__logo, styles.user__logo_answered]}>
                                        <UserB />
                                    </View>
                                    <View style={[styles.user__descr, styles.user__descr_answered]}>
                                        <Text style={styles.user__text}><Text style={styles.user__name}>Nickname</Text>         Дата: 12.08.21  16:36</Text>
                                        <Text style={styles.user__text}>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. </Text>
                                    </View>
                                </View>
                            </View>

                            {changePost ?
                                <View style={styles.editPost}>
                                    <Text style={styles.editPost__head}>
                                        <Text style={[styles.user__name, styles.user__name_me]}>You</Text>         Дата: 12.08.21  16:36
                                    </Text>

                                    <TextInput
                                        style={styles.editPost__input}
                                        multiline={true}
                                        value={"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat."}
                                    />
                                    <View style={styles.editPost__btns}>
                                        <TouchableOpacity style={styles.editPost__btn_cancel}>
                                            <Text style={styles.editPost__btn_cancel_text}>ОТМЕНА</Text>
                                        </TouchableOpacity>
                                        <TouchableOpacity onPress={() => setChangePost(!changePost)} style={styles.editPost__btn_post}>
                                            <Text style={styles.editPost__btn_post_post_text}>ПУБЛИКОВАТЬ</Text>
                                        </TouchableOpacity>
                                    </View>


                                </View>
                                :
                                <View style={styles.user__answered}>
                                    <View style={styles.user}>
                                        <View style={[styles.user__logo, styles.user__logo_me]}>
                                            <UserB />
                                        </View>
                                        <View style={[styles.user__descr, styles.user__descr_answered,]}>
                                            <Text style={styles.user__text}><Text style={[styles.user__name, styles.user__name_me]}>You</Text>         Дата: 12.08.21  16:36</Text>
                                            <Text style={styles.user__text}>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. </Text>
                                            <View style={styles.user__links}>
                                                <TouchableOpacity onPress={() => setChangePost(!changePost)} style={styles.user__link}><Text style={styles.user__link_text}>Редактировать</Text></TouchableOpacity>
                                                <TouchableOpacity style={styles.user__link}><Text style={[styles.user__link_text, styles.user__link_delete]}>Удалить</Text></TouchableOpacity>
                                            </View>
                                        </View>
                                    </View>
                                </View>
                            }

                            <View style={styles.user}>
                                <View style={styles.user__logo}>
                                    <UserB />
                                </View>
                                <View style={styles.user__descr}>
                                    <Text style={styles.user__text}><Text style={styles.user__name}>Nickname</Text>         Дата: 12.08.21  16:36</Text>
                                    <Text style={styles.user__text}>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. </Text>
                                    <TouchableOpacity style={styles.user__link}><Text style={styles.user__link_text}>Ответить</Text></TouchableOpacity>
                                </View>
                            </View>




                            {/* </ScrollView> */}
                        </View>
                    </View>
                </View>
            </ScrollView>
        </View>
    );
}



const styles = StyleSheet.create({
    container: {
        backgroundColor: "#E5E5E5",
        flex: 1,
        flexDirection: 'column',
        justifyContent: 'center'
    },
    header: {
        flexDirection: 'row',
        width: '90%',
        paddingTop: 50,
        justifyContent: 'space-between',
        alignSelf: 'center',
        marginBottom: 40
    },
    backView: {
        width: '100%',
        height: 50,
        backgroundColor: '#fff',
        alignItems: 'center',
        borderRadius: 50,
        justifyContent: 'center',
        flexGrow: 0,
        flexShrink: 1,
        flexBasis: '15%'
    },
    textView: {
        flexGrow: 1,
        flexShrink: 1,
        flexBasis: '60%',
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center'
    },
    textView_block: {
        width: '100%',
        textAlign: 'center'
    },
    circle: {
        width: '100%',
        height: 50,
        flexGrow: 0,
        flexShrink: 1,
        flexBasis: '15%',
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        borderWidth: 2,
        borderColor: '#159CE4',
        borderRadius: 50
    },
    circleText: {
        fontSize: 15,
        color: '#159CE4'
    },
    headerTitle: {
        width: '100%',
        fontSize: 20,
        fontWeight: 'bold',
        letterSpacing: 1,
        color: '#374957',
        textAlign: 'center',
    },
    content: {
        width: '100%',
        flexBasis: '100%',
        flexShrink: 1,
        flexGrow: 0,
        flexWrap: 'wrap',
        flexDirection: 'row',
        justifyContent: 'center',
    },
    detail: {
        width: '90%',
    },
    detail__title: {
        color: '#374957',
        fontWeight: '700',
        fontSize: 16,
        textTransform: 'uppercase',
        marginBottom: 10
    },
    detail__description: {
        color: '#374957',
        fontSize: 15,
        fontWeight: '300',
        letterSpacing: 1,
        marginBottom: 20
    },
    detail__info: {
        paddingBottom: 20,
        borderColor: '#374957',
        borderBottomWidth: 1,
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        borderBottomWidth: 1,
        borderColor: '#374957',
        paddingBottom: 10
    },
    detail__comment: {
        flexGrow: 0,
        flexShrink: 1,
        flexBasis: '85%'
    },
    comment__blue: {
        color: '#159CE4'
    },
    detail__text: {
        color: '#374957',
    },
    detail__btnAdd: {
        width: '100%',
        height: 50,
        backgroundColor: '#fff',
        alignItems: 'center',
        borderRadius: 50,
        justifyContent: 'center',
        flexGrow: 0,
        flexShrink: 1,
        flexBasis: '15%'
    },
    detail__users: {
        width: '100%',
        height: '100%',
        flexDirection: 'column',
        alignItems: 'flex-end'
    },
    user: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingVertical: 10,
        paddingHorizontal: -10,
        borderBottomWidth: 2,
        borderColor: 'rgba(55, 73, 87, 0.1)',
    },
    user__logo: {
        width: '100%',
        height: 50,
        backgroundColor: '#fff',
        alignItems: 'center',
        borderRadius: 50,
        justifyContent: 'center',
        marginRight: 15,
        flexGrow: 0,
        flexShrink: 1,
        flexBasis: '15%'
    },
    user__descr: {
        flexGrow: 0,
        flexShrink: 1,
        flexBasis: '80%'
    },
    user__text: {
        fontSize: 14,
        marginBottom: 10
    },
    user__name: {
        fontWeight: '700',
        marginRight: 20
    },
    user__name_me: {
        color: '#159CE4'
    },
    user__link: {
    },
    user__link_text: {
        color: '#159CE4',
        textDecorationLine: 'underline'
    },
    user__answered: {
        width: '80%'
    },
    user__descr_answered: {
        flexGrow: 0,
        flexShrink: 1,
        flexBasis: '80%'
    },
    user__links: {
        flexDirection: 'row',
        justifyContent: 'space-between'
    },
    user__logo_answered: {
        flexGrow: 0,
        flexShrink: 1,
        flexBasis: '20%'
    },
    user__logo_me: {
        backgroundColor: '#26E415',
        flexGrow: 0,
        flexShrink: 1,
        flexBasis: '20%'
    },
    user__link_delete: {
        color: '#f00'
    },
    editPost: {
        marginTop: 20
    },
    editPost__head: {
        marginBottom: 10
    },
    editPost__input: {
        paddingVertical: 20,
        paddingLeft: 20,
        paddingRight: 20,
        borderRadius: 20,
        backgroundColor: '#fff',
        marginBottom: 10
    },
    editPost__btns: {
        width: "70%",
        justifyContent: "space-between",
        flexDirection: "row",
        marginTop: "2%",
        marginLeft: "2%",
        marginBottom: "5%",
    },
    editPost__btn_cancel: {
        borderColor: "#159CE4",
        borderWidth: 2,
        width: "48%",
        height: 45,
        borderRadius: 20,
        alignContent: "center",
        justifyContent: "center",
    },
    editPost__btn_post: {
        backgroundColor: "#159CE4",
        borderColor: "#159CE4",
        borderWidth: 2,
        width: "48%",
        height: 45,
        borderRadius: 20,
        alignContent: "center",
        justifyContent: "center",
    },
    editPost__btn_cancel_text: {
        color: "black",
        fontSize: 12,
        textAlign: "center",
    },
    editPost__btn_post_post_text: {
        color: "white",
        fontSize: 12,
        textAlign: "center",
    }
});