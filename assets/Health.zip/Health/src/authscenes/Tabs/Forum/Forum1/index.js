import React, { useState } from "react";
import { useNavigation } from "@react-navigation/native";
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  TextInput,
  ScrollView,
  Picker,
} from "react-native";
import BackIcon from "../../../../../assets/images/backicon.svg";
import SearchIcon from "../../../../../assets/images/search.svg";
import Line from "../../../../../assets/images/line.svg";
import Sort from "../../../../../assets/images/sort.svg";
import SortActive from "../../../../../assets/images/sort-active.svg";
import SortFilter from "../../../../../assets/images/sort-gray.svg";
import Add from "../../../../../assets/images/plus.svg";
import Question from "./Question/Question";
import Tabs from "../..";

export default function Forum1() {
  const [filterSearch, setFilterSearch] = useState(false);
  const [selectedValue, setSelectedValue] = useState("Самые новые темы");

  const navigation = useNavigation();
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity
          onPress={() => navigation.navigate("Forum")}
          style={styles.backView}
        >
          <BackIcon />
        </TouchableOpacity>
        <View style={styles.textView}>
          <View style={styles.textView_block}>
            <Text style={styles.headerTitle}>Форум</Text>
            <Line width={100} alignSelf="center" marginTop={4} />
          </View>
        </View>
        <View style={styles.circle}>
          <Text style={styles.circleText}>3</Text>
        </View>
      </View>
      <ScrollView showsVerticalScrollIndicator={false} showsHorizontalScrollIndicator={false} style={{ height: '100%' }}>
        <View style={styles.menuSettings}>
          <View style={styles.search}>
            <TextInput
              style={styles.searchText}
              placeholder="Искать на форуме..."
              placeholderTextColor="#B4D1D7"
            />
            <SearchIcon />
          </View>
          <View style={filterSearch ? styles.sorting : styles.sorting_active}>
            <TouchableOpacity onPress={() => setFilterSearch((prev) => !prev)}>
              {filterSearch ? <Sort /> : <SortActive />}
            </TouchableOpacity>
          </View>
        </View>

        {filterSearch ? (
          <View style={styles.dropDownWrapper}>
            <SortFilter />
            <Picker
              selectedValue={selectedValue}
              style={styles.dropDown}
              onValueChange={(itemValue, itemIndex) =>
                setSelectedValue(itemValue)
              }
            >
              <Picker.Item label="Самые новые темы" value="Самые новые темы" />
              <Picker.Item
                label="Cамые старые темы"
                value="Cамые старые темы"
              />
              <Picker.Item label="Новая активность" value="Новая активность" />
              <Picker.Item
                label="Старая активность"
                value="Старая активность"
              />
            </Picker>
          </View>
        ) : null}

        <View style={styles.content}>
          <View style={styles.content__title}>
            <View style={styles.content__title_texts}>
              <Text style={styles.content__title_title}>
                Негативный опыт в сфере предоставлении медицинских услуг
              </Text>
              <Text style={styles.content__title_theme}>
                Темы: <Text style={styles.content__theme_int}>15</Text>
              </Text>
            </View>

            <View style={styles.content__title_btnAdd}>
              <TouchableOpacity
                onPress={() => navigation.navigate("ForumCreate")}
              >
                <Add />
              </TouchableOpacity>
            </View>
          </View>

          <View style={styles.content__questions}>
            {/* <ScrollView> */}
            <Question
              navPath="Forum2"
              text="Девочки, кто лечился у Комаровского?"
              commentCount="1"
              author="Nickname"
              date="12.08.21"
              time="16:36"
            />
            <Question
              navPath="Forum2"
              text="Мск, клиника на Ленина"
              commentCount="5"
              author="Nickname"
              date="12.08.21"
              time="16:36"
            />
            <Question
              navPath="Forum2"
              text="Хирург забыл в полости веник :( Что делать?"
              commentCount="4"
              myComment={true}
              myCommentCount="3"
              author="Nickname"
              date="12.08.21"
              time="16:36"
            />
            <Question
              i={true}
              navPath="Forum2"
              text="Как установить RedHat под FreeBSD?"
              commentCount="125"
              myCommentCount="3"
              author="Nickname"
              date="12.08.21"
              time="16:36"
            />
            <Question
              navPath="Forum2"
              text="Хочу услышать отзывы о докторе N. "
              commentCount="4"
              myCommentCount="3"
              author="Nickname"
              date="12.08.21"
              time="16:36"
            />
            <Question
              navPath="Forum2"
              text="Как дела?"
              commentCount="4"
              myComment={true}
              myCommentCount="3"
              author="Nickname"
              date="12.08.21"
              time="16:36"
            />
            <Question
              navPath="Forum2"
              text="Как дела?"
              commentCount="4"
              myCommentCount="3"
              author="Nickname"
              date="12.08.21"
              time="16:36"
            />
            <Question
              i={true}
              navPath="Forum2"
              text="Как дела?"
              commentCount="4"
              myCommentCount="3"
              author="Nickname"
              date="12.08.21"
              time="16:36"
            />
            <Question
              navPath="Forum2"
              text="Как дела?"
              commentCount="4"
              myComment={true}
              myCommentCount="3"
              author="Nickname"
              date="12.08.21"
              time="16:36"
            />
            {/* </ScrollView> */}
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

// navPath
// i
// text
// commentCount
// myCommentCount
// author
// date
// time
// myComment

const styles = StyleSheet.create({
  container: {
    backgroundColor: "#E5E5E5",
    flex: 1,
    flexDirection: "column",
    justifyContent: "center",
  },
  header: {
    flexDirection: "row",
    width: "90%",
    paddingTop: 50,
    justifyContent: "space-between",
    alignSelf: "center",
    marginBottom: 40,
  },
  backView: {
    width: "100%",
    height: 50,
    backgroundColor: "#fff",
    alignItems: "center",
    borderRadius: 50,
    justifyContent: "center",
    flexGrow: 0,
    flexShrink: 1,
    flexBasis: "15%",
  },
  textView: {
    flexGrow: 1,
    flexShrink: 1,
    flexBasis: "60%",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  textView_block: {
    width: "100%",
    textAlign: "center",
  },
  circle: {
    width: "100%",
    height: 50,
    flexGrow: 0,
    flexShrink: 1,
    flexBasis: "15%",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 2,
    borderColor: "#159CE4",
    borderRadius: 50,
  },
  circleText: {
    fontSize: 15,
    color: "#159CE4",
  },
  headerTitle: {
    width: "100%",
    fontSize: 20,
    fontWeight: "bold",
    letterSpacing: 1,
    color: "#374957",
    textAlign: "center",
  },
  menuSettings: {
    width: "90%",
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    alignSelf: "center",
  },
  search: {
    backgroundColor: "#ffffff",
    height: 50,
    borderRadius: 100,
    flexDirection: "row",
    justifyContent: "space-between",
    alignSelf: "center",
    alignItems: "center",
    paddingHorizontal: 20,
    flexGrow: 0,
    flexShrink: 1,
    flexBasis: "80%",
  },
  searchText: {
    fontSize: 12,
  },
  sorting: {
    width: "100%",
    height: 50,
    backgroundColor: "#fff",
    alignItems: "center",
    borderRadius: 50,
    justifyContent: "center",
    flexGrow: 0,
    flexShrink: 1,
    flexBasis: "15%",
  },
  sorting_active: {
    width: "100%",
    height: 50,
    backgroundColor: "#374957",
    alignItems: "center",
    borderRadius: 50,
    justifyContent: "center",
    flexGrow: 0,
    flexShrink: 1,
    flexBasis: "15%",
  },
  dropDownWrapper: {
    width: "90%",
    alignSelf: "center",
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    backgroundColor: "#fff",
    marginTop: 15,
    borderRadius: 100,
    overflow: "hidden",
    paddingHorizontal: 20,
  },
  dropDown: {
    width: "100%",
    // height: 30,
    paddingHorizontal: 15,
    paddingVertical: 10,
  },
  content: {
    width: "100%",
    flexBasis: "100%",
    flexShrink: 1,
    flexGrow: 0,
    flexWrap: "wrap",
    flexDirection: "row",
    justifyContent: "center",
    paddingTop: 35,
  },
  content__title: {
    width: "90%",
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-start",
    borderBottomWidth: 1,
    borderColor: "#374957",
    paddingBottom: 10,
  },
  content__title_texts: {
    flexBasis: "85%",
    flexShrink: 1,
    flexGrow: 0,
  },
  content__title_title: {
    fontSize: 14,
    fontWeight: "bold",
    textTransform: "uppercase",
  },
  content__title_theme: {
    fontSize: 14,
  },
  content__theme_int: {
    fontWeight: "bold",
  },
  content__title_btnAdd: {
    width: "100%",
    height: 50,
    backgroundColor: "#fff",
    alignItems: "center",
    borderRadius: 50,
    justifyContent: "center",
    flexGrow: 0,
    flexShrink: 1,
    flexBasis: "15%",
  },
  content__questions: {
    width: "90%",
  },
});
